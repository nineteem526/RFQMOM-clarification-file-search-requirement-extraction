# RFQMOM澄清文件检索与要求提取

[![CI](https://github.com/Jingqian-Liu_duerr/RFQMOM-clarification-file-search-requirement-extraction/actions/workflows/ci.yml/badge.svg)](https://github.com/Jingqian-Liu_duerr/RFQMOM-clarification-file-search-requirement-extraction/actions/workflows/ci.yml)

面向工程采购文件（RFQ、B12、澄清文件、TE / DF MOM）的 Windows 本地工具：检索要求、比对差异、整理待确认事项，并通过公司内部 AI 接口生成**带逐字出处**的审核草稿。所有 AI 结果都是草稿，须人工审核，不构成工程批准或标准合规结论。

## 仓库组成

| 目录 | 定位 | 状态 | 说明 |
|---|---|---|---|
| [`kotaemon-source/`](kotaemon-source/README.md) | **工程知识问答助手（主线）** | 本机和 Azure 单实例试点 | 基于 Kotaemon 0.12.0：多格式解析、本地向量检索、带引用回答、后台查询、备份恢复。运行环境需单独准备。 |
| 根目录（`app.py` 等） | Streamlit 虚构示例（早期原型） | 演示，仅内置虚构 TXT | 轻量展示“检索 → 选片段 → AI 提取 → 逐字引用校验”流程，依赖仅 Streamlit 和 OpenAI SDK。 |

新功能请在 `kotaemon-source` 中开发；根目录示例保留用于演示和回归，不扩展到真实数据。

```text
.
├── app.py / workbench.py / samples.py   Streamlit 示例：页面、索引与 API 校验、虚构样例
├── tests/                               示例的自动化测试
├── start.ps1                            示例启动脚本
├── kotaemon-source/                     工程知识问答助手源码快照
│   ├── project_app.py                   界面与本机 HTTP 服务（Gradio + FastAPI）
│   ├── project_workspace.py             项目存储、录入、检索与快照
│   ├── company_chat.py / network_access.py  公司 API 适配与访问边界
│   ├── environment-setup/               依赖约束与模型哈希清单
│   └── tests/                           离线回归测试
├── .github/workflows/ci.yml             持续集成
└── LICENSE                              授权占位（保留所有权利）
```

## 快速开始

- **Streamlit 示例**：见下文[组件一](#组件一streamlit-虚构示例)，Python 3.11+，`pip install -r requirements.txt` 后运行 `start.ps1`。
- **工程知识问答助手**：见 [`kotaemon-source/README.md`](kotaemon-source/README.md)。需要已批准的专用运行环境、模型文件和公司端点配置，克隆仓库本身不能直接运行。
- **Azure App Service 测试部署**：见 [`kotaemon-source/README.md` 的 Python 代码部署指南](kotaemon-source/README.md#azure-app-service-python-代码部署)；不同环境的访问边界和部署结果须分别验证。

## 当前进展（2026-11-18）

- 已在现有 Azure App Service 上完成单实例 Python 代码部署和一次授权资料快照迁移；源码仓库不包含业务文件、索引、迁移包或密钥。
- 当前试点以公司指定公网出口限制网页和部署入口，不要求用户登录；同一出口的人员均可访问和修改数据，不代表具备生产级身份认证或权限管理。
- 资料已建立索引，但解析有覆盖限制；AI 问答尚未配置公司接口和密钥，本地文件后续变更也不会自动同步。具体状态及待办见[试点进展](kotaemon-source/README.md#azure-poc-progress-2026-11-17)。

## 配置（环境变量）

| 变量 | 组件 | 用途 |
|---|---|---|
| `DUERR_API_KEY` | 两者 | 公司 API 密钥，仅从进程环境读取，不写入文件 |
| `DUERR_API_ENDPOINT` | 两者 | 公司 HTTPS 基础端点 |
| `DUERR_API_ALLOWED_HOST` | 示例 | 允许访问的端点主机名 |
| `DUERR_API_APPROVED_ENDPOINT` | 助手 | 管理员批准的端点（白名单） |
| `DUERR_API_VERSION` / `DUERR_MODEL` | 两者 | API 版本与部署名，默认 `2025-04-01-preview` / `gpt-5.2` |
| `RFQ_WORKBENCH_DB` | 示例 | 演示数据库路径，默认 `%LOCALAPPDATA%\RFQWorkbench\demo.sqlite3` |
| `RFQ_AUTHORIZED_SOURCE` | 助手 | 授权资料目录，默认仓库同级的 `评审后`；修改属于授权变更，已有项目仍绑定原目录 |

仓库不保存任何公司端点或密钥。

## 持续集成

GitHub Actions 在 Windows 上运行：

- 根目录示例全部测试（Python 3.11 / 3.12）；
- `kotaemon-source` 中不依赖 Kotaemon 运行时、模型和 NLTK 资源的纯逻辑测试（API 探测、网络边界、Office 转换、资料扫描、授权目录、合成响应校验）。

其余 Kotaemon 测试需要专用运行环境，CI 无法覆盖，修改相关模块后须在本机按 [`kotaemon-source/README.md`](kotaemon-source/README.md#offline-regression-tests) 运行完整测试。CI 不访问公司 API，也不读取业务文件。

## 授权

见 [`LICENSE`](LICENSE)。目前为“保留所有权利”占位，正式授权条款待权利人确定。

---

## 组件一：Streamlit 虚构示例

把 RFQ、B12、澄清文件及 TE / DF MOM 的描述按关键词汇总，辅助查找要求、差异和待确认事项，并可将用户选中的片段交给企业 AI 接口生成带逐字出处的审核草稿。`kotaemon-pilot` 是本机安装目录，`评审后` 是真实业务资料目录，两者均不纳入版本控制。

### 功能组成

- **本地检索**：SQLite 保存文档版本和原文片段；关键词、任意词命中、内置术语扩展及 RFQ / TE / DF 阶段筛选。
- **版本留存**：同一版本幂等录入，冲突内容拒绝覆盖；各文件版本并列保留，不以日期推断优先级。
- **证据约束的 AI 草稿**：发送前展示完整请求内容并要求用户确认；只允许配置的企业 HTTPS 主机；AI 输出须为 JSON，来源 ID 和引文通过逐字校验后才显示。
- **结果导出**：草稿连同原始出处及局限性导出为 JSON；源示例也可打包下载。
- **本地优先**：页面仅监听 `127.0.0.1`，演示索引写入 `%LOCALAPPDATA%\RFQWorkbench\demo.sqlite3`（可用 `RFQ_WORKBENCH_DB` 覆盖），不存放在项目目录。

### 技术结构

| 文件 | 职责 |
|---|---|
| `app.py` | Streamlit 页面、检索交互、发送前预览与结果展示 |
| `workbench.py` | SQLite 索引、片段检索、企业 API 限制、请求和引文校验 |
| `samples.py` | 虚构的 RFQ / B12 / 澄清 / MOM 样例与术语扩展 |
| `tests/` | 存储、检索、API 请求校验和页面流程自动化测试 |
| `start.ps1` | Windows 本机启动入口 |

### 当前边界

- **只接受程序内置的虚构 TXT 示例。真实文件导入和发送禁用。**没有 PDF、扫描件 OCR、Word、Excel 或 PowerPoint 解析。
- 检索在本地完成：关键词、空格分隔多词的任一匹配、内置术语扩展。不是自然语言语义检索；术语扩展可能带来不相关结果。
- 所有版本保留，重复录入不新增；不以日期判定优先级，不自动覆盖旧版本。阶段筛选由用户选择。
- API 只接入指南中的公司 HTTPS 代理；密钥仅从当前进程环境读取，不写文件、不显示、不记录。不自动重试、不使用外部回退。
- 发送前显示完整片段及出处元数据，用户确认后才调用。查询词不会发送给 API，AI 分析选中的全部片段。
- AI 必须返回 JSON，出处 ID 和引文须通过逐字校验。不合格结果整份拒绝。校验不能证明提取描述正确，仍须人工审核。
- **没有可核查标准资料，国标 / ISO / 美标建议禁用。**后续需要合法获准使用的标准原文、版本、适用国家/地区及工程范围；不能用模型记忆代替标准条款。
- 这是单用户演示，不具备生产项目隔离、多用户权限、审批流或正式审计能力。
- 本仓库不包含真实客户资料、项目文档、模型/解析运行时、向量库或本机安装环境。

### 安装与启动

需要 Windows、Python 3.11 或更新版本。依赖只包含 Streamlit 和 OpenAI Python SDK。
在本目录 PowerShell 执行：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\start.ps1
```

若公司策略禁止运行 PowerShell 脚本，不要降低执行策略；直接执行等效命令：

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py --server.address 127.0.0.1 --server.port 8501 --server.headless true --browser.gatherUsageStats false
```

浏览器打开 `http://127.0.0.1:8501`。服务器仅监听本机，不应改为公网监听。终端按 Ctrl+C 停止。
网页不加载外部字体、脚本或标准检索服务；Streamlit 用量遥测在启动参数中关闭。

### 内部 API

按公司正式接入指南，在**启动程序的同一终端**配置：

- `DUERR_API_KEY`：项目专用密钥。使用指南的隐藏输入方式，不粘贴到聊天、源码或日志。
- `DUERR_API_ENDPOINT`：公司指南中的 HTTPS 基础端点。
- `DUERR_API_ALLOWED_HOST`：该端点的主机名（不带协议、端口或路径）；程序拒绝其他主机。
- `DUERR_API_VERSION`：默认 `2025-04-01-preview`。
- `DUERR_MODEL`：默认 `gpt-5.2`，部署名区分大小写，以公司实际配置为准。

仓库不保存公司端点或密钥。未配置端点和允许主机时，API 功能不可用；只从公司正式指南取得配置值。先在“内部 AI 接入”中执行固定指令的最小聊天测试。成功后再用虚构片段验证提取。
普通聊天成功不代表 JSON 输出、复杂提取或标准建议能力已经通过验证。
请求使用 `temperature=1`、`max_completion_tokens`，与指南一致；不假定代理支持结构化输出、工具调用或嵌入接口。
输出不完整、无内容、拒答或 JSON/引用校验失败会显示错误，不保存为成功结果。
HTTP 错误仅显示状态码和请求 ID，不显示可能包含请求内容的原始错误响应。

### 示例流程与预期结果

1. 点击“录入 RFQ / B12 / 澄清示例”，得到三个文件版本；再次点击新增数为零。
2. 检索“钢构”：应命中 RFQ 的平台荷载 / 结构计算书、B12 的维修平台荷载，以及澄清文件的供货边界 / 荷载待确认描述。
3. 在左侧逐次录入 TE MOM R1、R2 和 DF MOM，旧版本不消失。筛选 TE 后只展示 TE 片段。
4. 检索“电气控制”：可查看 RFQ 的冗余电源 / 急停、B12 的 IP54、TE 的拟议 IP55 和 DF 的待批准状态。
5. 选择片段、查看发送预览、确认虚构数据后调用 AI；结果必须带原文引用。IP55 不应被描述为已批准；文件日期不应被解释为优先级。
6. 下载 JSON 结果，包含查询、要求草稿、完整出处及局限性，便于人工复核。AI 的具体条目数量并非固定。

源文件可通过左侧下载 ZIP 查看；不修改业务文件，也不执行 Excel 自动化。
演示索引存储在 `%LOCALAPPDATA%\RFQWorkbench\demo.sqlite3`，不放入当前 OneDrive 工作目录。非 Windows 环境或需要隔离时，可设置 `RFQ_WORKBENCH_DB` 指定数据库文件完整路径。
索引跨重启保留；AI 结果仅保存在当前页面会话，长期保留需显式下载。

### 本地验证

```powershell
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

自动测试使用临时数据库和伪造 API 响应，不发送网络请求、不读取业务文件。
真实服务的连通性、当前部署及语义质量需在公司网络中使用虚构示例单独验证。

### 仓库范围与安全

Git 忽略规则排除了 `评审后`、`kotaemon-pilot`、本机环境、日志、数据库、密钥文件及常见业务文档格式。`kotaemon-source` 只保存经整理的程序源码、测试和必要配置模板，不包含业务数据或公司端点。提交前仍应检查待提交文件清单；忽略规则不能替代人工审查。

### 转为真实项目工具前

必须确认客户端及业务数据用途获准、支持的文件格式、项目访问范围、存储与保留策略，以及客户文件的替代/优先级规则。
届时增加真实解析、项目隔离、原文件校验与精确页码/条款定位；扫描件需 OCR 质量提示。
移除演示白名单限制应作为独立授权变更，不能仅因拥有 API 密钥就启用真实数据。
